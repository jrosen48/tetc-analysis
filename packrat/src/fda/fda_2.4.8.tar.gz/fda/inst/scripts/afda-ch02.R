###
###
### Ramsey & Silverman (2002) Applied Functional Data Analysis (Springer)
###
### ch. 2.  Life Course Data in Criminology 
###
library(fda)

# Data not available.  
