# evaluator

<details>

* Version: 0.4.0
* Source code: https://github.com/cran/evaluator
* URL: https://evaluator.tidyrisk.org
* BugReports: https://github.com/davidski/evaluator/issues
* Date/Publication: 2019-04-10 16:17:58 UTC
* Number of recursive dependencies: 134

Run `revdep_details(,"evaluator")` for more info

</details>

## Newly broken

*   checking whether the package can be loaded ... ERROR
    ```
    Loading this package had a fatal error status code 1
    Loading log:
    Error: package or namespace load failed for ‘evaluator’:
     object ‘vec_unspecified_cast’ is not exported by 'namespace:vctrs'
    Execution halted
    ```

# probably

<details>

* Version: 0.0.2
* Source code: https://github.com/cran/probably
* URL: https://github.com/tidymodels/probably/
* BugReports: https://github.com/tidymodels/probably/issues
* Date/Publication: 2019-03-07 17:40:08 UTC
* Number of recursive dependencies: 70

Run `revdep_details(,"probably")` for more info

</details>

## Newly broken

*   checking whether the package can be loaded ... ERROR
    ```
    Loading this package had a fatal error status code 1
    Loading log:
    Error: package or namespace load failed for ‘probably’:
     object ‘vec_type2.character’ is not exported by 'namespace:vctrs'
    Execution halted
    ```

