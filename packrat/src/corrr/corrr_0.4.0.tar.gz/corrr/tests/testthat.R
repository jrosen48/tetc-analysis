library(testthat)
library(corrr)
library(dplyr)

test_check("corrr")
