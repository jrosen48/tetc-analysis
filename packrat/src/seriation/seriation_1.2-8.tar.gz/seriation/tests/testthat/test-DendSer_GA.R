library(seriation)

## just check if we can register them

## somehow this registers them before!

#context("DendSer")
#register_DendSer()

#context("GA")
#register_GA()

